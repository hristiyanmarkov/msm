file="GaussII.dat"
GaussII	=read.table(file=file,header=T)

######
######################################## flexmix
######
require("flexmix")
require("MASS")

eqscplot(GaussII[,-3])
plot(GaussII[,-3])

sum(GaussII	[,"c"]==1) #sum(GaussII	$c==1)
sum(GaussII	[,"c"]==2) #sum(GaussII	$c==2)

m1 <- flexmix(y ~ x , data = GaussII	, k = 2,
	      model = FLXMRglm(family = "gaussian"))
m1

##
## to get the estimated parameters of mixture components 1,2, ...
##
parameters(m1, component = 1)
parameters(m1, component = 2)

m1.reflx <- refit(m1)
summary(m1.reflx)

m1 <- flexmix(y ~ x , data = GaussII	, k = 2,
	      model = FLXMRglm(family = "gaussian"))
m1

##
## cross-tabulation of true classes and cluster memberships can be obtained by
##
table(GaussII$c, clusters(m1))

##
## summary
##
summary(m1)

##
## Tests for significance of regression coefficients can be obtained by
## The function refit() fits weighted Generalized Linear Models to each component 
## using the glm() procedure and the posterior probabilities as weights, 
## More details can be found in help("refit")
## 

rm1 <- refit(m1)
summary(rm1)

#GaussII.pr <- predict(m1, newdata = GaussII	)

plot(y~x, col=c, pch=c, data=GaussII	)
matplot(GaussII$x, fitted(m1), type="l", add=TRUE, col=6:7)

##################### robust regressionwise clustering
require(tclust)
source("tclustReg.r")
X=GaussII[,-3]

K <- 2
alpha.1 <- 0.1
alpha.2 <- 0.1
factor <- 6
a <- tclust.reg(X,K,factor,alpha.1,alpha.2,output=TRUE)

GaussII=read.table("GaussII.cont.dat",header=T)
