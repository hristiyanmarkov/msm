##
############################## Multivariate Unsupevised Learning
##
## Nclus data - four 2-dimensional Gaussian clusters
## 

require("flexmix")
require("ellipse")
require("mvtnorm")
require("MASS")
source("mymclust.R")
set.seed(1504)
options(width=60)
grDevices::ps.options(family="Times")

data("Nclus")
m1 <- flexmix(Nclus ~ 1, k = 4, model = mymclust())
summary(m1)

m2 <- flexmix(Nclus ~ 1, k = 4, model = mymclust(diagonal = FALSE))
summary(m2)

par(mfrow=c(2,1))
plotEll(m1, Nclus)
plotEll(m2, Nclus)

eqscplot(Nclus, col=rep(1:4, c(100, 100, 150, 200)))

n=100+100+150+200
##
## This model is wrong (one component has a non-diagonal cov matrix)
##
Formula=as.formula("Nclus~1")
ex0 <- flexmix(Formula, k=4, model=FLXMCmvnorm(diagonal=FALSE))  
print(ex0)
summary(ex0)
parameters(ex0, component=1)
parameters(ex0, component=2)
parameters(ex0, component=3)
parameters(ex0, component=4)
parameters(ex0)

#
#plotEll(ex0, Nclus)
#
ex0.flx <- refit(ex0)
summary(ex0.flx)


ex0 <- initFlexmix(Formula, k=2:6, model=FLXMCmvnorm(diagonal=FALSE),
                   control=list(minprior=0), nrep=2)
ex0
plot(ex0)
(ex0.flx.BIC=getModel(ex0, which="BIC"))
plotEll(ex0.flx.BIC, Nclus)

ex0.flx.26=getModel(ex0, which="ICL")
ex0.flx.26
summary(relab.ex0.flx.26)

plotEll(ex0.flx.26, Nclus)
relab.ex0.flx.26=relabel(ex0.flx.26)

##
table(clusters(ex0.flx.26))
parameters(ex0.flx.26)
ncomp=attr(ex0.flx.26,"k")
print(c(ncomp=ncomp))
cluster=attr(relab.ex0.flx.26,"cluster")
tau=attr(relab.ex0.flx.26,"posterior")[1]

#############
#
# predicted values
#
file="Nclusnew.dat"
wrk=read.table(file=file,header=T)
ex0.pred <- predict(ex0, newdata = wrk,aggregate =T)

ncomp=attr(ex0,"k")
print(c(ncomp=ncomp))
cluster=attr(ex0,"cluster")
tau=attr(ex0,"posterior")[1]
Qf=fitted(ex0)
dim(tau[[1]]) # 1st element of the list
B=tau[[1]]
################# dim(B)  550x4
################# dim(Qf) 550x4

C=Qf*B        # dim(C) 823x3 matrix multiplication column-wise
dim(C)
ysh=rowSums(C)  # fitted value due to the mixture model


##
## True model, true number of components
##

ex0 <- flexmix(Formula, k=6, model=FLXMCmvnorm(diagonal=T))  
print(ex0)

plotEll(ex0, Nclus)

## Get parameters of the component
parameters(ex0, component=1)
parameters(ex0, component=2)
parameters(ex0, component=3)
parameters(ex0, component=4)
parameters(ex0)
plotEll(ex0, Nclus)

ex0.flx <- refit(ex0)
summary(ex0.flx)
Lapply(ex0, "vcov", 2)

ex0 <- initFlexmix(Formula, k=2:7, model=FLXMCmvnorm(diagonal=F),
                   control=list(minprior=0), nrep=2)
ex0=stepFlexmix(Formula, k=2:10, model=FLXMCmvnorm(diagonal=F),
                   control=list(minprior=0), nrep=2)                   
ex0
plot(ex0)
ex0.26=getModel(ex0, which="ICL")
ex0.26

plotEll(ex0.26, Nclus)
relab.ex0.26=relabel(ex0.26)
relab.ex0.26
plotEll(relab.ex0.26, Nclus)



table(clusters(relab.ex0.26))
parameters(relab.ex0.26)
ncomp=attr(relab.ex0.26,"k")
print(c(ncomp=ncomp))
cluster=attr(relab.ex0.26,"cluster")
cluster
tau=attr(relab.ex0.26,"posterior")[1]
##
## Now try the univariate case
##
plot(density(Nclus[,1]))

exp11 <- flexmix(Nclus[,1]~1, cluster=cut(Nclus[,1], 3), model=FLXMCnorm1())
exp11
parameters(exp11)


plot(density(Nclus[,2]))

exp12 <- flexmix(Nclus[,1]~1, cluster=cut(Nclus[,2], 3), model=FLXMCnorm1())
exp12
parameters(exp12)


##
## True model, wrong covariance matrix - diagonal
##
ex0 <- flexmix(Nclus~1, k=4, model=FLXMCmvnorm(diagonal=T))  
print(ex0)

plotEll(ex0, Nclus)

##
## True model, wrong number of components
##
ex00 <- flexmix(Nclus~1, k=6, model=FLXMCmvnorm(diagonal=FALSE))  
print(ex00)

plotEll(ex00, Nclus)

ex00step<-initFlexmix(Nclus~1, k=1:5, model=FLXMCmvnorm(diagonal=FALSE),
                   nrep = 5)

getModel(ex00step, "BIC")
plotEll(ex00step, Nclus)

## try 5 times for k=4
set.seed(611)
ex1 <- initFlexmix(Nclus~1, k=4, model=FLXMCmvnorm(diagonal=FALSE),
                   nrep = 5)
ex1
plot(ex1)
##
## get BIC values
##
BIC(ex1)
ICL(ex1)
## now 3 times each for k=2:6, specify control parameter
ex2 <- initFlexmix(Nclus~1, k=2:6, model=FLXMCmvnorm(diagonal=FALSE),
                   control=list(minprior=0), nrep=3)
ex2
plot(ex2)
cluster

##
## get BIC values
##
BIC(ex2)

## get smallest model
getModel(ex2, which=1)

## get model with 3 components
getModel(ex2, which="3")

## get model with smallest ICL (here same as for AIC and BIC: true k=4)
getModel(ex2, which="ICL")
getModel(ex2, which="BIC")
getModel(ex2, which="AIC")
getModel(ex2)


## now 1 time each for k=2:6, with larger minimum prior
ex3 <- initFlexmix(Nclus~1, k=2:6, model=FLXMCmvnorm(diagonal=FALSE),
                   control=list(minprior=0.1), nrep=1)
ex3
getModel(ex3)


	tau=attr(ex1,"posterior")[1]
	Qf=fitted(ex1)
	B=tau[[1]]
	C=Qf*B        								#dim(C) 823x3 matrix multiplication column-wise


#####################################
set.seed(1504)
library("graphics")
library("flexmix")
data("NPreg")

par(mfrow=c(1,2))
plot(yn~x, col=class, pch=class, data=NPreg)
plot(yp~x, col=class, pch=class, data=NPreg)

m1 <- flexmix(yn ~ x + I(x^2), data = NPreg, k = 2)
m1

summary(m1)

parameters(m1, component = 1)
parameters(m1, component = 2)

table(NPreg$class, clusters(m1))
m1@prior
m1@cluster
m1@size
m1@size[1]
m1@size[2]
m1@components$Comp.1
m1@components$Comp.2
m1@posterior$scaled
m1@posterior$scaled[1:10,]
head(m1@posterior$scaled)

################
rm1 <- refit(m1)
summary(rm1)


################
m2 <- flexmix(yp ~ x, data = NPreg, k = 2, 
		model = FLXMRglm(family = "poisson"))
summary(m2)
print(plot(m2))

m3 <- flexmix(~ x, data = NPreg, k = 2,
		model=list(FLXMRglm(yn ~ . + I(x^2)), 
			FLXMRglm(yp ~ ., family = "poisson")))
summary(m3)
print(plot(m3))
table(NPreg$class, clusters(m3))

m7 <- stepFlexmix(yp ~ x + I(x^2), data = NPreg,
		control = list(verbose = 0), k = 1:5, nrep = 5)

m7
summary(m7)
getModel(m7)
getModel(m7, "BIC")

m8 <- flexmix(yp ~ x + I(x^2), data = NPreg, k = 2,
  control = list(minprior = 0.2))
summary(m8)
parameters(m8, component = 1)
parameters(m8, component = 2)
m8.refit=refit(m8)
summary( m8.refit)


m5 <- flexmix(yn ~ x + I(x^2), data = NPreg, k = 2,
	control = list(iter.max = 15, verbose = 3, classify = "hard"))

print(plot(m5))
	