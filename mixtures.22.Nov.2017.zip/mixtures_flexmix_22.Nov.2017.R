library("flexmix")
require("flexmix")
require("ellipse")
require("mvtnorm")
require("MASS")
source("mymclust.R")
data("NPreg")

##
##

dim(NPreg)
head(NPreg)
sum(NPreg[,"class"]==1)
sum(NPreg$class==1)
sum(NPreg[,"class"]==2)
sum(NPreg$class==2)

##
##

plot(yn~x, col=class, pch=class, data=NPreg)
##
##

m1 <- flexmix(yn ~ x + I(x^2), data = NPreg, k = 2,
	      model = FLXMRglm(family = "gaussian"))
m1

##
## to get the estimated parameters of mixture components 1,2, ...
##
parameters(m1, component = 1)
parameters(m1, component = 2)

##
## cross-tabulation of true classes and cluster memberships can be obtained by
##
table(NPreg$class, clusters(m1))

##
## summary
##
summary(m1)

##
## Tests for significance of regression coefficients can be obtained by
## The function refit() fits weighted Generalized Linear Models to each component 
## using the glm() procedure and the posterior probabilities as weights, 
## More details can be found in help("refit")
## 

rm1 <- refit(m1)
summary(rm1)

NPreg.pr <- predict(m1, newdata = NPreg)

plot(yn~x, col=class, pch=class, data=NPreg)
matplot(NPreg$x, fitted(m1), type="l", add=TRUE, col=6:7)
#for (i in 1:2) lines(NPreg$x, sort(NPreg.pr[[i]]), lty = i)

##
##################### Mixture of two Poisson regression models
##
##		Class ?1: log(lambda1) = 2 + 0.2x
##		Class ?2: log(lambda2) = 1 + 0.1x

plot(yp~x, col=class, pch=class, data=NPreg)

##

m2 <- flexmix(yp ~ x, data = NPreg, k = 2, 
	      model = FLXMRglm(family = "poisson"))

parameters(m2, component = 1)
parameters(m2, component = 2)

##

rm2 <- refit(m2)
summary(rm2)

summary(m2)
plot(m2)

##
##
##
rm2 <- refit(m2)
summary(rm2)

plot(m2)

##
##
##
m5 <- flexmix(yn ~ x + I(x^2), data = NPreg, k = 2,
  control = list(iter.max = 15, verbose = 3, classify = "hard"))

summary(m5)
plot(m5)

##
## ako nqkoq ot komponentite e s po-malka veroqtnost ot minprior da bude izkluchena ot analiza
##


m6 <- flexmix(yp ~ x + I(x^2), data = NPreg, k = 4,
  control = list(minprior = 0.2))

m6 
 
summary(m6)
plot(m6)


###################################################
###  In real applications the number of components is unknown and has to be estimated 
###  based on AIC, BIC using stepFlexmix() which repeatedly fit models
###
###################################################
##
## mixture of 2 normal regression lines 
##
## runs flexmix() 5 times for k = 1, 2, . . . , 5 components, totalling in 25 runs!!!
##

m7n <- stepFlexmix(yn ~ x + I(x^2), data = NPreg,
  control = list(verbose = 0), k = 1:5, nrep = 5)

m7n

##
getModel(m7n, "BIC")


##
## mixture of 2 Poisson regression lines 
##

m7p <- stepFlexmix(yp ~ x + I(x^2), data = NPreg,
  control = list(verbose = 0), k = 1:5, nrep = 5)

getModel(m7p, "BIC")

################################################################
##
## now we fit a model with one Gaussian response and one Poisson
## response. Note that the formulas inside the call to FLXMRglm are
## relative to the overall model formula.
##
ex2 <- flexmix(yn~x+I(x^2), data=NPreg, k=2,
               model=list(FLXMRglm(yn~x+I(x^2)), 
                          FLXMRglm(yp~x+I(x^2), family="poisson")))
plot(ex2)

ex2
table(ex2@cluster, NPreg$class)

## for Gaussian responses we get coefficients and standard deviation
parameters(ex2, component=1, model=1)
parameters(ex2, component=2, model=1)

## for Poisson response we get only coefficients
parameters(ex2, component=1, model=2)
parameters(ex2, component=2, model=2)

##
############################## Multivariate Unsupevised Learning
##
## Nclus data - four 2-dimensional Gaussian clusters
## 

data("Nclus", package = "flexmix")
require("MASS")
eqscplot(Nclus, col=rep(1:4, c(100, 100, 150, 200)))


##
## True model, true number of components
##
ex0 <- flexmix(Nclus~1, k=4, model=FLXMCmvnorm(diagonal=FALSE))  
ex0 <- flexmix(Nclus~1, k=6, model=FLXMCmvnorm(diagonal=T))  
print(ex0)

plotEll(ex0, Nclus)

## Get parameters of first component
parameters(ex0, component=1)
parameters(ex0, component=2)

##
## Now try the univariate case
##
plot(density(Nclus[,1]))

exp11 <- flexmix(Nclus[,1]~1, cluster=cut(Nclus[,1], 3), model=FLXMCnorm1())
exp11
parameters(exp11)


plot(density(Nclus[,2]))

exp12 <- flexmix(Nclus[,1]~1, cluster=cut(Nclus[,2], 3), model=FLXMCnorm1())
exp12
parameters(exp12)


##
## True model, wrong covariance matrix - diagonal
##
ex0 <- flexmix(Nclus~1, k=4, model=FLXMCmvnorm(diagonal=T))  
print(ex0)

plotEll(ex0, Nclus)

##
## True model, wrong number of components
##
ex00 <- flexmix(Nclus~1, k=6, model=FLXMCmvnorm(diagonal=FALSE))  
print(ex00)

plotEll(ex00, Nclus)

ex00step<-initFlexmix(Nclus~1, k=1:5, model=FLXMCmvnorm(diagonal=FALSE),
                   nrep = 5)

getModel(ex00step, "BIC")
plotEll(getModel(ex00step, "BIC"), Nclus)

## try 5 times for k=4
set.seed(611)
ex1 <- initFlexmix(Nclus~1, k=4, model=FLXMCmvnorm(diagonal=FALSE),
                   nrep = 5)
ex1
plot(ex1)
##
## get BIC values
##
BIC(ex1)
ICL(ex1)
## now 3 times each for k=2:6, specify control parameter
ex2 <- initFlexmix(Nclus~1, k=2:6, model=FLXMCmvnorm(diagonal=FALSE),
                   control=list(minprior=0), nrep=3)
ex2
plot(ex2)
cluster

##
## get BIC values
##
BIC(ex2)

## get smallest model
getModel(ex2, which=1)

## get model with 3 components
getModel(ex2, which="3")

## get model with smallest ICL (here same as for AIC and BIC: true k=4)
getModel(ex2, which="ICL")
getModel(ex2, which="BIC")
getModel(ex2, which="AIC")
getModel(ex2)

#########stewise stepFlexmix
ex2=stepFlexmix(Formula, k=2:10, model=FLXMCmvnorm(diagonal=F),
                   control=list(minprior=0), nrep=2)                   
ex2
ex2.BIC=getModel(ex2, which="BIC")
getModel(ex2, which="AIC")
getModel(ex2)
print(plot(ex2.BIC))


## now 1 time each for k=2:6, with larger minimum prior
ex3 <- initFlexmix(Nclus~1, k=2:6, model=FLXMCmvnorm(diagonal=FALSE),
                   control=list(minprior=0.1), nrep=1)
ex3
getModel(ex3)


###################
##############################
# GLMs single Poisson regression model 
#
#
require(flexmix)
data("seizure")
#data=read.table("seizure.dat",header=T)
#seizure=as.data.frame(data)                   
 
# Seizures=seizure$Seizures 
#    Hours=seizure$Hours 
#Treatment=seizure$Treatment 
#      Day=seizure$Day   
Treatment=as.factor(Treatment)      
is.factor(Treatment)

plot(Seizures/Hours~Day, col=as.integer(Treatment),
     pch=as.integer(Treatment), data=seizure)
abline(v=27.5, lty=2, col="grey")
legend(140, 9, c("Baseline", "Treatment"),
       pch=1:2, col=1:2, xjust=1, yjust=1)
       
seizGLM <- glm(Seizures~Treatment*log(Day),family=poisson,offset=log(Hours),data=seizure)
summary( seizGLM)
fitted(seizGLM)
round(cbind(fitted(seizGLM),seizure$Seizures))
matplot(seizure$Day, fitted(seizGLM)/seizure$Hours, type="l", add=TRUE, col=6:7)

################ Mixtires of two Poisson distributions
library(flexmix)
data("seizure")
plot(Seizures/Hours~Day, col=as.integer(Treatment),
     pch=as.integer(Treatment), data=seizure)
abline(v=27.5, lty=2, col="grey")
legend(140, 9, c("Baseline", "Treatment"),
       pch=1:2, col=1:2, xjust=1, yjust=1)


set.seed(123)

## The model presented in the Wang et al paper: two components for
## "good" and "bad" days, respectively, each a Poisson GLM with hours of
## parental observation as offset

seizMix <- flexmix(Seizures~Treatment*log(Day),
                   data=seizure, k=2,
                   model=FLXMRglm(family="poisson", offset=log(seizure$Hours)))

summary(seizMix)
summary(refit(seizMix))

matplot(seizure$Day, fitted(seizMix)/seizure$Hours, type="l",
        add=TRUE, col=3:4)

seizGLM <- glm(Seizures~Treatment*log(Day),family=poisson,offset=log(Hours),data=seizure)
matplot(seizure$Day, fitted(seizGLM)/seizure$Hours, type="l", add=TRUE, col=6)




######################### Tribolium beetles
## 
## The data investigates whether the adult Tribolium species Castaneum has developed 
## an evolutionary advantage to recognize and avoid eggs of their own species while foraging. 

data("tribolium", package = "flexmix")
tribMix <- initFlexmix(cbind(Remaining, Total - Remaining) ~ Species, 
                   k = 2, nrep=5, data = tribolium,
                   model = FLXMRglm(family = "binomial"))
aa=refit(tribMix)
summary(aa)


#################################### 
 library("flexmix")

 Component_1 <- list(Model_1 = list(coef = c(1, -2), sigma = sqrt(0.1)))

 Component_2 <- list(Model_1 = list(coef = c(2, 2), sigma = sqrt(0.1)))
 ArtEx.mix <- FLXdist(y ~ x, k = rep(0.5, 2),
 components = list(Component_1, Component_2))

#########################

 data("NregFix", package = "flexmix")
 Model <- FLXMRglm(~ x2 + x1)
 fittedModel <- stepFlexmix(y ~ 1, model = Model, nrep = 3, k = 3,
 data = NregFix, concomitant = FLXPmultinom(~ w))
 summary(refit(fittedModel))


#########################
data("salmonellaTA98", package = "flexmix")

salmonMix <- initFlexmix(y ~ 1,
                         data = salmonellaTA98, 
                         model = FLXMRglmfix(family = "poisson", 
                           fixed = ~ x + log(x + 10)),                        
                         k = 2, nrep = 5)
salmonMix.pr <- predict(salmonMix, newdata = salmonellaTA98)
plot(y ~ x, data = salmonellaTA98, 
     pch = as.character(clusters(salmonMix)), 
     ylim = range(c(salmonellaTA98$y, unlist(salmonMix.pr))))
for (i in 1:2) lines(salmonellaTA98$x, salmonMix.pr[[i]], lty = i)

bb=glm(y ~ x + log(x + 10), data = salmonellaTA98, family = "poisson") 
lines(salmonellaTA98$x, bb$fitted, col="red")
#########################


data("betablocker", package = "flexmix")


betaGlm
summary(betaGlm)



 betaMixFix <- stepFlexmix(cbind(Deaths, Total - Deaths) ~ 1 | Center,
	  model = FLXMRglmfix(family = "binomial", fixed = ~ Treatment),
	  k = 2:4, nrep = 3, data = betablocker)

betaMixFix
plot(betaMixFix, mark = 2, col = "grey", markcol = 1)

betaMix <- initFlexmix(cbind(Deaths, Total-Deaths) ~ 1 | Center,
                       data=betablocker, k=3, nrep=5,
                       model=FLXMRglmfix(family="binomial",
                         fixed=~Treatment)) 

betaMix
summary(betaMix)

parameters(betaMix)
table(clusters(betaMix))

predict(betaMix, newdata = data.frame(Treatment = c("Control", "Treated")))
fitted(betaMix)[c(1, 23), ]

summary(refit(getModel(betaMixFix, "3")))



#################### trypanosome

data("trypanosome", package = "flexmix")
TrypMix <- stepFlexmix(cbind(Dead, 1-Dead) ~ 1, k = 2, nrep = 3,
 data = trypanosome, model = FLXMRglmfix(family = "binomial",
 fixed = ~ log(Dose)))

TrypMix <- stepFlexmix(cbind(Dead, 1-Dead) ~ 1, k = 2, nrep = 3,
 data = trypanosome, model = FLXMRglmfix(family = "binomial",
 fixed = ~ log(Dose)))

aa=refit(TrypMix)
summary(aa)
plot(aa)

summary(refit(TrypMix))

# newdata 
tab <- with(trypanosome, table(Dead, Dose))
Tryp.dat <- data.frame(Dead = tab["1",], Alive = tab["0",], Dose = as.numeric(colnames(tab)))
#
plot(Dead/(Dead+Alive) ~ Dose, data = Tryp.dat)
#
# classical glm  - one component
#
Tryp.glm <- glm(cbind(Dead, 1-Dead) ~ log(Dose), family = "binomial", data = trypanosome)
#
Tryp.pred <- predict(Tryp.glm, newdata=Tryp.dat, type = "response")
#Tryp.pred <- predict(glm(cbind(Dead, 1-Dead) ~ log(Dose), family = "binomial", data = trypanosome), newdata=Tryp.dat, type = "response")
TrypMix.pred <- as.matrix(as.data.frame(predict(TrypMix, newdata = Tryp.dat)) ) %*% TrypMix@prior
lines(Tryp.dat$Dose, Tryp.pred, lty = 2)
lines(Tryp.dat$Dose, TrypMix.pred, lty = 3)
legend(4.7, 1, c("GLM", "Mixture model"), lty=c(2, 3), xjust=0, yjust=1)

#trypMix <- initFlexmix(cbind(Dead, 1-Dead) ~ 1, k = 2, 
#	               nrep=5, data = trypanosome,
#	               model = FLXMRglmfix(family = "binomial",
#                          fixed = ~log(Dose)))

#require(flexmix)
# variable names: End Begin Gender Ethnic Treatment
data("dmft")

# standard Poison regression model
fm_pois <- glm(End ~ log(Begin + 0.5) + Gender + Ethnic + Treatment , data = dmft, family = poisson)
summary(fm_pois)
anova(fm_pois,test="Chisq")
#
# mixture of two Poison regression models
#
Model <- FLXMRziglm(family = "poisson")
Fitted <- flexmix(End ~ log(Begin + 0.5) + Gender + Ethnic + Treatment,
	 model = Model, k = 2 , data = dmft, control = list(minprior = 0.01))
summary(refit(Fitted))
summary(Fitted)



