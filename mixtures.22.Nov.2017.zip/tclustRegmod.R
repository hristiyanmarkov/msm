#source("tclustRegmod.R")

#######################################################################################
#######################################################################################
##     Function tclust.reg                                                          ###
#######################################################################################
#######################################################################################

# Needs library MASS
library(MASS)

##################################################################
## Generate data:
##################################################################
## First p-1 columns are the explanatory variables (without the 1's column)
# and the p-th column is the outcome or response variable

##################################################################
## This junction serves to find the closest scatter parameters vector
# but satisfying  the scatter ratio constraint.
# A quadratic programing problem must be solved with LowRankQP 

# Needs library LowRankQP 
library(LowRankQP)

qua.di <- function(gg,factor){
	# g.new will the new scatters
	g.new <- gg

	if (length(gg)>1){
		#Sort scatters
        	or <- sort(gg,index.return=TRUE)
		g <- or$x

		maximun <- 10^20

		# Constant "c" defining the scatter constrain
		factor <- factor+0.0001

		# n.scat is the number of scatter parameters
		n.scat <- length(g)

		Amat <- matrix(rep(0,n.scat*n.scat),nrow=n.scat)
		rr <- (1:n.scat)
		for (i in (1:(n.scat-1))){
			Amat[i,i] <- -1
			Amat[i,i+1] <- 1
			}

		# Definition of the quadratic problem
		Amat[n.scat,1] <- factor
		Amat[n.scat,n.scat] <- -1
		Vmat <- diag(c(rep(1,n.scat),rep(0,n.scat)))
		dvec <- -c(t(g),rep(0,n.scat))
		bvec <- rep(0,n.scat)
		uvec <- rep(maximun,2*n.scat)
		Amat <- cbind(Amat,(-1)*diag(n.scat))

		# Solve this quadratic problem
		a <- LowRankQP(Vmat,dvec,Amat,bvec,uvec,method="CHOL")
		g.new <- as.vector(a$alpha[1:n.scat])

		#Original order
		g.new[or$ix] <- g.new
		}
return(g.new)
}


##################################################################
# function tclust.reg
##################################################################
# X is the matrix with data values (first p-1 columns are the explanatory variables (without the 1's column)
# and the last column is the outcome variable y)
# K is the number of groups we search for
# alpha.1 is the firts trimming level
# alpha.2 is the second trimming level
# factor is the constant c controlling the scatter constrain
# niter is the number or random starts
# Ksteps is the number of concentration steps



tclust.reg <- function(X,K,factor,alpha.1,alpha.2,niter=20,Ksteps=10,output=FALSE){
    
    # The data is converted into a matrix
    X <- as.matrix(X)

    # Dimensions
    n <- dim(X)[1]
    p <- dim(X)[2]


    # First 'trimmed and non trimmed' proportions
    no.trim <- floor(n*(1-alpha.1))
    trimm <- n-no.trim

    # Total trimming after second trimming
    trimm2 <- floor(n*(1-alpha.1)*(1-alpha.2))

    # Initialize vector and matrices
    ll <-matrix((1:(n*K)),ncol=K)
    ind <- (1:n)
    dist <- ind
    ni <- rep(1,K)
    sigma.opt <- rep(1,K)
    b.opt <- matrix((1:(K*p)),ncol=p)
    num.opt <- (1:K)
    
    #Initialize the objective function through a very small value
    vopt <- -10^10

    ## Ramdon restarts 
    for (iter in 1:niter){

	if (output==TRUE) {cat("iteration = ", iter, "\n")}

	# Initial sigmas
        sigma.ini <- rep(1,K)

	# Initial n's
	ni.ini <- floor(rep(n*(1-alpha.1),K)/K)

        ## Initialize betas
	bini <- matrix((1:(K*p)),ncol=p)
	
	# Search for K*p random points avoiding group degeneracies for the x's 
	repeat{
		points <- X[sample(1:n,size=K*p,replace=F),]
		degen <- 0
		for (k in 1:K){
			if ( det(cbind(rep(1,p),points[(1+(k-1)*p):(k*p),1:(p-1)]))==0 ) {degen <- 1}
			}
		if (degen==0) break 
		}

	# Initial betas are obtained solving a linear system
	for (k in 1:K){
			bini[k,] <- solve(cbind(rep(1,p),points[(1+(k-1)*p):(k*p),1:(p-1)]),points[(1+(k-1)*p):(k*p),p])
		}
      
        ## Concentration steps

	ind.old <- rep (-1, n)
        for (t in 1:Ksteps){

            	# Discriminant functions for the assignments
            	for (k in 1:K){
          	              ll[,k] <- (ni.ini[k]/n)*dnorm(X[,p]-cbind(rep(1,n),X[,1:(p-1)])%*%bini[k,],0,sqrt(sigma.ini[k]))
          	              }
           	dist <- apply(ll,1,max)
            	ind <- apply(ll,1,which.max)
                    
            	# Modified data (Xmod) with the non-trimmed points and last 
            	# column equal to the cluster allocations
            	qq <- (1:n)[dist>=sort(dist)[trimm+1]]
            	xmod <- as.matrix(cbind(X[qq,],ind[qq]))

            	# If any cluster is void or with fewer than p+1 elements we stop the concentration steps (control != 0)...
	    	for (k in 1:K){
	                    ni[k] <- sum(xmod[,p+1]==k)  
            		}
            	ni[is.na(ni)] <- 0
	    	control <- sum( ni <= p+1 )

	    	if (control==0) {
	            	#Calculus of the new k regression parameters and the new sigmas
			xmod.temp <- NULL
            		for (k in 1:K){
				# Data points in each group
				xmod.k <- xmod[xmod[,p+1]==k,(1:p)]
				
				# Perform the second trimming
				if(alpha.2==0) {qqs <- 1:ni[k]} else { qqs <- cov.mcd(xmod.k[,(1:(p-1))],quantile.used = floor(ni[k]*(1-alpha.2)))$best}
				
				# Update betas through ordinary least squares regression
				xxx <- xmod.k[qqs,(1:(p-1))]
				yyy <- xmod.k[qqs,p]
                        	ni[k] <- length(yyy)       
				reg <- lm(yyy~xxx)
                        	bini[k,] <- reg$coefficients

				# Update sigmas through the mean square residuals
                        	sigma.ini[k] <- sum(reg$residuals^2)/ni[k]

				# Update weights
				ni.ini[k] <- ni[k]
				xmod.temp <- rbind(xmod.temp,cbind( xxx, yyy, rep(k,ni[k]) ) )				                            
            			}

			# New xmod
			xmod <- xmod.temp

			## If the scatters do not satisfies the restriction then a quadratic programming problem is solved
			sigma.ini <- (qua.di((sigma.ini)^(-1), factor))^(-1)
	    	       }

		# This criterium serves to stop if two consecutive concentration steps has the same result
		if (!any (ind != ind.old)) {break} 
	    	ind.old <- ind

                }

    # After the concentration steps, we compute the value of the target function
    obj <- 0
    for (k in 1:K){
               obj <- ifelse(control==0,obj+ ni.ini[k]*log(ni.ini[k]/trimm2)+sum(log(dnorm(xmod[xmod[,p+1]==k,p]-(   cbind(rep(1,ni.ini[k]),xmod[xmod[,p+1]==k,(1:(p-1))])%*%bini[k,]   ),0,sqrt(sigma.ini[k])))),obj-10^10)
	}
       
    # Change the 'optimal' target value and 'optimal' parameters if a increase in the target value is achieved
    if (obj >= vopt){
        	vopt <- obj
        	b.opt <- bini
        	num.opt <- ni.ini
    		sigma.opt <- sigma.ini        	
        	} 
    	}

    ## Last part of the program prepares some graphs and numerical outputs for the program
    # Assignment vectors: asig.1 are the clusters after the first trimming and asig.2 after the second 
    asig.1 <- rep(0,n)
    asig.2 <- rep(0,n)	

    for (k in 1:K){
             ll[,k] <- (num.opt[k]/n)*dnorm(X[,p]-cbind(rep(1,n),X[,1:(p-1)])%*%b.opt[k,],0,sqrt(sigma.opt[k]))
        	}
    dist <- apply(ll,1,max)
    ind <- apply(ll,1,which.max)
    val <- sort(dist)[trimm+1]

    for (k in 1:K){
	     asig.1[(ind==k)&(dist>=val)] <- k
		}

    # A graph summarizing the results is given is dimension is equal p = 2
    if (p==2 & output==TRUE){
	  plot(X,xlab="x",ylab="y",type="n")
	  points(X[dist<val,],col=1)
	    }

    qq <- (1:n)[dist>=sort(dist)[trimm+1]]
    xmod <- as.matrix(cbind(X[qq,],ind[qq]))

    for (k in 1:K){
		qqk <- qq[xmod[,p+1]==k]
		ni[k] <- sum(xmod[,p+1]==k) 
		xmod.k <- xmod[xmod[,p+1]==k,]
		if(alpha.2==0) {qqs <- 1:ni[k]} else { qqs <- cov.mcd(xmod.k[,(1:(p-1))],quantile.used = floor(ni[k]*(1-alpha.2)))$best}
		xxx <- xmod.k[qqs,1]
		yyy <- xmod.k[qqs,2]
		xxx0 <- xmod.k[-qqs,1]
		yyy0 <- xmod.k[-qqs,2]
		if (p==2 & output==TRUE){
   			points(xxx,yyy,col=k+1,pch=k+2)   
   			points(xxx0,yyy0,col=1,pch=19,cex=0.5) 
			}
		qqf <- qqk[qqs]
		asig.2[qqf] <- k
		reg <- lm(yyy~xxx)
		if (p==2 & output==TRUE){           
			abline(reg$coefficients)
			}
		}

    if (output==TRUE){
		## Some numerical results...
		cat("\n")
		cat("Proportion of observations non discarded = ",trimm2/n, "\n")
		cat("\n")
		cat("Sigmas = ",sqrt(sigma.opt), "\n")
		cat("\n")
		cat("Groups sizes = ",num.opt/trimm2, "\n")
		cat("\n")
		cat("Target function = ",vopt, "\n")
		cat("\n")
		}

   ## Return the values for the function
   # b.opt are the regression parameters
   # sigma.opt are the estimated group variances
   # num.opt are the number of observations in each cluster after the second trimming
   # vopt is the value of the target function
   # asig.1 is the cluster assigments after first trimming ('0' means a trimmed observation...)
   # asig.2 is the (-final-) cluster assigments after second trimming ('0' means a trimmed observation...)   
   return(list(b.opt=b.opt,sigma.opt=sigma.opt,num.opt=num.opt,vopt=vopt,asig.1=asig.1,asig.2=asig.2))
}

