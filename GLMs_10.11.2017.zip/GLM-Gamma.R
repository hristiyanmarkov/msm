#
#
# Car insurance data - Gamma distribution
#
#Car insurence data from McCullagh and Nelder (1989) GLMs., p. 289. 
#The response is the average claim in pounds (AvCost). 
#The number  of claims (NClaims) in each category
#This is a 8x4x5 factorial, but there are 5 cells for which there are no observations.
#OwnerAge
#    a factor with levels: 17-20, 21-24, 25-29, 30-34, 35-39, 40-49, 50-59, 60+
#AvOwnerAge    
#    a numeric vector
#Model
#    a factor with levels: A, B, C, D 
#CarAge
#    a factor with levels: 0-3, 10+, 4-7, 8-9 
#NClaims
#    a numeric vector
#AvCost
#    a numeric vector
#
data=read.table("CarInsurance.dat",skip=15,header=T)
CarInsurance=as.data.frame(data)
    
OwnerAge=CarInsurance$OwnerAge
Model=CarInsurance$Model
CarAge=CarInsurance$CarAge
NClaims=CarInsurance$NClaims
AvCost=CarInsurance$AvCost
OwnerAge=as.factor(OwnerAge)
Model=as.factor(Model)    
CarAge=as.factor(CarAge)
#
#Gamma(link = "inverse")
#   
car.glm.1=glm(AvCost~.,data=CarInsurance,family=Gamma(inverse),weight=NClaims)
summary(car.glm.1)
#
car.glm.OwnerAge=glm(AvCost~OwnerAge,data=CarInsurance,family=Gamma(inverse),weight=NClaims)
summary(car.glm.OwnerAge)
anova(car.glm.1,car.glm.OwnerAge,test="Chi")
#
car.glm.OwnerAge.Model=glm(AvCost~OwnerAge+Model,data=CarInsurance,family=Gamma(inverse),weight=NClaims)
summary(car.glm.OwnerAge.Model)
anova(car.glm.1,car.glm.OwnerAge,car.glm.OwnerAge.Model,test="Chi")
#
car.glm.OwnerAge.Model.CarAge=glm(AvCost~OwnerAge+Model+CarAge,data=CarInsurance,family=Gamma(inverse),weight=NClaims)
summary(car.glm.OwnerAge.Model.CarAge)
anova(car.glm.1,car.glm.OwnerAge,car.glm.OwnerAge.Model,car.glm.OwnerAge.Model.CarAge,test="Chi")
#
car.glm.OwnerAge.Model.CarAge.2=glm(AvCost~OwnerAge:Model+CarAge,data=CarInsurance,family=Gamma(inverse),weight=NClaims)
summary(car.glm.OwnerAge.Model.CarAge.2)
anova(car.glm.1,car.glm.OwnerAge,car.glm.OwnerAge.Model,car.glm.OwnerAge.Model.CarAge,car.glm.OwnerAge.Model.CarAge.2,test="Chi")

car.glm.OwnerAge.Model.CarAge.2.2=glm(AvCost~OwnerAge:Model+OwnerAge:CarAge,data=CarInsurance,family=Gamma(inverse),weight=NClaims)
summary(car.glm.OwnerAge.Model.CarAge.2.2)
anova(car.glm.1,car.glm.OwnerAge,car.glm.OwnerAge.Model,car.glm.OwnerAge.Model.CarAge,
car.glm.OwnerAge.Model.CarAge.2,car.glm.OwnerAge.Model.CarAge.2.2,test="Chi")

car.glm.OwnerAge.Model.CarAge.2.2.2=glm(AvCost~OwnerAge:Model+OwnerAge:CarAge+Model:CarAge,data=CarInsurance,family=Gamma(inverse),weight=NClaims)
summary(car.glm.OwnerAge.Model.CarAge.2.2.2)
anova(car.glm.1,car.glm.OwnerAge,car.glm.OwnerAge.Model,car.glm.OwnerAge.Model.CarAge,
car.glm.OwnerAge.Model.CarAge.2,car.glm.OwnerAge.Model.CarAge.2.2,car.glm.OwnerAge.Model.CarAge.2.2.2,test="Chi")

car.glm.OwnerAgeModelCarAge=glm(AvCost~OwnerAge*Model*CarAge,data=CarInsurance,family=Gamma(inverse),weight=NClaims)
summary(car.glm.OwnerAgeModelCarAge)
anova(car.glm.1,car.glm.OwnerAge,car.glm.OwnerAge.Model,car.glm.OwnerAge.Model.CarAge,
car.glm.OwnerAge.Model.CarAge.2,car.glm.OwnerAge.Model.CarAge.2.2,
car.glm.OwnerAge.Model.CarAge.2.2.2,car.glm.OwnerAgeModelCarAge,test="Chi")

#### An appropriate model might the main effects model
car.glm.OwnerAge.Model.CarAge=glm(AvCost~OwnerAge+Model+CarAge,data=CarInsurance,family=Gamma(inverse),weight=NClaims)
summary(car.glm.OwnerAge.Model.CarAge)
anova(car.glm.1,car.glm.OwnerAge,car.glm.OwnerAge.Model,car.glm.OwnerAge.Model.CarAge,test="Chi")


########################## family=Gamma(link="log")
car.1=glm(AvCost~1,data=CarInsurance,family=Gamma(log),weight=NClaims)
summary(car.1)
#
car.OwnerAge=glm(AvCost~OwnerAge,data=CarInsurance,family=Gamma(log),weight=NClaims)
summary(car.OwnerAge)
anova(car.1,car.OwnerAge,test="Chi")
#
car.OwnerAge.Model=glm(AvCost~OwnerAge+Model,data=CarInsurance,family=Gamma(log),weight=NClaims)
summary(car.OwnerAge.Model)
anova(car.1,car.glm.OwnerAge,car.OwnerAge.Model,test="Chi")
#
car.OwnerAge.Model.CarAge=glm(AvCost~OwnerAge+Model+CarAge,data=CarInsurance,family=Gamma(log),weight=NClaims)
summary(car.OwnerAge.Model.CarAge)
anova(car.1,car.OwnerAge,car.OwnerAge.Model,car.OwnerAge.Model.CarAge,test="Chi")

car.OwnerAge.Model.CarAge.2.2.2=glm(AvCost~OwnerAge:Model+OwnerAge:CarAge+Model:CarAge,data=CarInsurance,family=Gamma(log),weight=NClaims)
summary(car.OwnerAge.Model.CarAge.2.2.2)
library(MASS)
aa=stepAIC(car.OwnerAge.Model.CarAge.2.2.2)



# A Gamma example, from McCullagh & Nelder (1989, pp. 300-2)
#Clotting time of blood, giving clotting times in seconds for 
#plasma diluted to nine different percemtage concentrations with 
#prothrombin-free plasma (u); clotting was induced by two lots of thromboplastin (clotting agent).
# Clotting time (Lot1 and Lot2)
#The data are as follows
clotting <- data.frame(
    u = c(5,10,15,20,30,40,60,80,100),
    lot1 = c(118,58,42,35,27,25,21,19,18),
    lot2 = c(69,35,26,21,18,16,13,12,12))
lot1.glm=glm(lot1 ~ log(u), data=clotting, family=Gamma)
summary(lot1.glm)
plot(x=log(clotting$u),y=clotting$lot1,pch="*")
lines(x=log(clotting$u),y=lot1.glm$fitted.values,col="blue")
lot2.glm=glm(lot2~ log(u), data=clotting, family=Gamma)
summary(lot2.glm)
plot(x=log(clotting$u),y=clotting$lot2,pch="*")
lines(x=log(clotting$u),y=lot2.glm$fitted.values,col="blue")

# Group of examples including Gamma regression
example(glm)
drop1(glm.D93, test="Chisq")
drop1(glm.D93, test="F")
  