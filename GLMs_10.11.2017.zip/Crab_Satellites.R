###########################
#
#                   Logistic regression for horseshoe crab data
#
### GLMs for count data - Poisson regression
#Data Number of Crab Satellites by female's Characteristics;
#color (1-light medium, 2 - medium, 3 - dark medium, 4 - dark)
#spine condition (1-both good, 2 - one worn or broken, 3 - both worn or broken,
#carapace width (cm)
#number of satellites 
#weight; 

options(contrasts=c("contr.treatment", "contr.poly"))
# table.4.3$Sa.bin<-ifelse(table.4.3$Sa>0,1,0)
data <- read.table("table.4.3.dat",skip=8,header=T)
table.4.3=as.data.frame(data)
#
 C=table.4.3$color     
 S=table.4.3$spine     
 W=table.4.3$width     
Sa=table.4.3$satellites
Wt=table.4.3$weight    

Sa.bin<-ifelse(Sa>0,1,0)
cbind(table.4.3,Sa.bin)
crab.fit.logit1<-glm(Sa.bin~W, family=binomial, data=table.4.3)
summary(crab.fit.logit1)
anova(crab.fit.logit1,test="Chisq")
#
#
#So, the estimated odds of having a satellite increase by 1.64 for each 1 cm 
# increase in width (a 64% increase).
#
summary(crab.fit.logit1, correlation=F)
#
#The Wald test is shown in the z value. To get the LRT, we need the log likelihood value 
#at the estimate and at the null value 0. For this we can use the deviance values.
LRT=crab.fit.logit1$null.deviance-crab.fit.logit1$deviance
df1=crab.fit.logist.full$df.null
df2=crab.fit.logist.full$df.residual
df=df1-df2
#with LR statistic
1 - pchisq(LRT,df=df)
#
C.fac<-factor(C, levels=c("5","4","3","2"), labels=c("dark","med-dark","med","med-light"))
is.factor(C.fac)

crab.fit.logit<-glm(Sa.bin~W+C.fac, family=binomial, data=table.4.3)
summary(crab.fit.logit, cor = F)
summary(crab.fit.logit)
anova(crab.fit.logit, test="Chisq")
#The model has a different intercept parameter (for the linear logit) 
#for crabs of different colors. For example, the logit model for dark crabs is
# logit(\pi )= -12.715 +0.468W and for medium crabs it is 
# logit(\pi )=(- 12.715+ 1.4023)+ 0.468W. 
#However, the slope on W(width) is always the same: Regardless of color, 
#a 1-cm increase in width has a multiplicative effect of exp(0.468) = 1.60 
#on the odds of having a satellite. Also, at any given width, the estimated 
#odds that a medium crab has a satellite are exp(1.4023 -1.1061) = 1.34 
#times the estimated odds for a medium-dark crab.

res1<-predict(crab.fit.logit, type="response", newdata=data.frame(W=seq(18,34,1),C.fac="med-light"))
res2<-predict(crab.fit.logit, type="response", newdata=data.frame(W=seq(18,34,1),C.fac="med"))
res3<-predict(crab.fit.logit, type="response", newdata=data.frame(W=seq(18,34,1),C.fac="med-dark"))
res4<-predict(crab.fit.logit, type="response", newdata=data.frame(W=seq(18,34,1),C.fac="dark"))

#Then, we plot the results:
plot(seq(18,34,1),res1,type="l",bty="L",ylab="Predicted Probability", axes=F,
xlab=expression(paste("Width, ", italic(x), "(cm)")))
axis(2, at=seq(0,1,.2))
axis(1, at=seq(18,34,2))

lines(seq(18,34,1),res2,col="2") # add colors 2-4
lines(seq(18,34,1),res3,col="3")
lines(seq(18,34,1),res4,col="4")
# add arrows and text
arrows(x0=29, res1[25-17],x1=25, y1=res1[25-17], length=.09)
text(x=29.1, y=res1[25-17], "Color 1", adj=c(0,0))
arrows(x0=23, res2[26-17],x1=26, y1=res2[26-17], length=.09)
text(x=21.1, y=res2[26-17], "Color 2", adj=c(0,0))
arrows(x0=28.9, res3[24-17],x1=24, y1=res3[24-17], length=.09)
text(x=29, y=res3[24-17], "Color 3", adj=c(0,0))
arrows(x0=25.9, res4[23-17],x1=23, y1=res4[23-17], length=.09)
text(x=26, y=res4[23-17], "Color 4", adj=c(0,0))

#To test whether the width effect changes at each color, 
#we can test the significance of a color by width
#interaction by fitting a new model with the addition of 
#this interaction and comparing the model deviance
#with that of the previous fit.
crab.fit.logit.ia <- update(object = crab.fit.logit, formula = ~ . + W:C.fac)
anova(crab.fit.logit, crab.fit.logit.ia, test = "Chisq")
#The p-value implies that an interaction model is not warranted.

#C.fac<-factor(C, levels=c("5","4","3","2"), labels=c("dark","med-dark","med","med-light"))
#is.factor(C.fac)

C.fac<-factor(C, levels=c("5","4","3","2"))
is.factor(C.fac)
S.fac<-factor(S, levels=c("3","2","1"))
is.factor(S.fac)
#Now, we fit the full model, with weight (Wt) being divided by 1000, as in the text. 
#Note the use of I() to interpret the argument literally.
#
crab.fit.logist.full<-glm(Sa.bin~C.fac+S.fac+W+I(Wt/1000), family=binomial,
					data=table.4.3)
summary(crab.fit.logist.full, cor=T)
anova(crab.fit.logist.full,test="Chisq")
LRT=crab.fit.logist.full$null.deviance-crab.fit.logist.full$deviance
df1=crab.fit.logist.full$df.null
df2=crab.fit.logist.full$df.residual
df=df1-df2
#with LR statistic
1 - pchisq(LRT,df=df)

#Because of the high correlation between width and weight, it is better to eliminate 
#the predictor Wt in further.
#To perform stepwise selection of predictor variables for various types of fitted models (including glm
#objects), one can use the function step with a lower and upper model specified. The criterion is AIC.
#Only the final model is printed unless trace=T is specified. An example of a call to the glm method is
#Type help(step)
step(crab.fit.logist.full, scope=list(lower = formula(crab.fit.logist.full), upper = ~ .^2 ), scale=1, trace=T, direction="both")
#
#The above call specifies both forward and backward stepwise selection of terms (direction="both").
#The scope of the selection has a lower bound or starting model as �fit�. The upper bound model
#includes all two-way interactions. The component �anova� gives a summary of the trace path.
#To illustrate stepwise procedures, we perform backward elimination on a model fitted to the horseshoe
#crab data. This model includes up to a three-way interaction among Color, Width, and Spine Condition.
#We fit this model using
#
crab.fit.logist.stuffed<-glm(Sa.bin~C.fac*S.fac*W, family=binomial,data=table.4.3)
#
#(Note that there are some warning messages after the fit.) The backward elimination begins with the
#above three-way interaction model. The lower bound of the scope is a null model. The upper bound is
#the saturated or �stuffed� model, as I appear to have called it.
#
res <- step(crab.fit.logist.stuffed, list(lower = ~ 1, upper =
formula(crab.fit.logist.stuffed)), scale = 1, trace = F, direction = "backward")
#
res$anova

#The stepAIC function from the MASS library also performs stepwise selection based on AIC. In some
#cases, the AIC calculation from stepAIC is more accurate than that of step procedure for glm. 
#See the help library for stepAIC or Venables and Ripley (2002). 
#Here, stepAIC gives the same anova summary.
library(MASS)
res <- stepAIC(crab.fit.logist.stuffed, list(lower = ~ 1, upper =
	formula(crab.fit.logist.full)), scale = 1, trace = F, direction = "backward")
#
res$anova
#
#If trace=T is specified a full output of all the intermediate models can be obtained
#
#
# Try forward (direction="forward") stepwise procedure and compare the output with the previous one.
#
res <- stepAIC(crab.fit.logist.stuffed, list(lower = ~ 1, upper =
	formula(crab.fit.logist.stuffed)), scale = 1, trace = F, direction = "forward")
res$anova
