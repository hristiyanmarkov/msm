#On the Aegean island of Kalythos the male inhabitants suffer from a 
#congenital eye disease,#the effects of which become more marked 
#with increasing age. Samples of islander males of various ages were
#tested for blindness and the results recorded. The data is shown below:
#Age: 20 35 45 55 70
#No. tested: 50 50 50 50 50
#No. blind: 6 17 26 37 44

kalythos <- data.frame(x = c(20,35,45,55,70), n = rep(50,5),
			y = c(6,17,26,37,44))
kalythos$Ymat <- cbind(kalythos$y, kalythos$n - kalythos$y)

#probit
fmp <- glm(Ymat ~ x, family = binomial(link=probit), data = kalythos)
summary(fmp)
#logit
fml <- glm(Ymat ~ x, family = binomial, data = kalythos)
summary(fml)
anova(fml)
attributes(fml)
fml$coefficients
coef(fml)

ld50 <- function(b) -b[1]/b[2]	
		
ldp <- ld50(coef(fmp)) 
ldl <- ld50(coef(fml))
c(ldp, ldl)

