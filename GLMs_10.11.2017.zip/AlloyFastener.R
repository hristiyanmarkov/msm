# Data from D. Collet - the compressive strenght of an alloy fastener used in aircraft constuction studied.
#Ten pressure loads, increasing in units of 200psi from 2500psi to 4300psi, were used
#n - number of fastener tested at each load
#r - number of these which Fail
#We assume that $r_i\~Bi(n_i,\pi_i)$ for $i=1,\ldots,10$ and that these 10 random variables are independent
data <- read.table("AlloyFastener.dat",skip=1,header=T)
AlloyF=as.data.frame(data)
Load=AlloyF$load
   n=AlloyF$n
   r=AlloyF$r
p<-r/n
plot(Load,p,type="l")
alloyf.glm<-glm(p~Load,weights=n, family=binomial)
attributes(alloyf.glm)
anova(alloyf.glm)
summary(alloyf.glm)
plot(alloyf.glm,ask=T) #for diagnostic plots
cbind(alloyf.glm$fitted.values,p,alloyf.glm$linear.predictors)
# alloyf.glm<-glm(p~Load+I(Load^2),weights=n, family=binomial) 


source("littleprog")
data; names(data); summary(data)
plot(Load,p,type="l")
alloyf.glm; summary(alloyf.glm)
names(alloyf.glm)
plot(alloyf.glm,ask=T) #for diagnostic plots
alloyf.glm.logit<-glm(p~Load,family=binomial(link=logit),weights=n)
alloyf.glm.probit<-glm(p~Load,family=binomial(link=probit),weights=n)
alloyf.glm.cloglog<-glm(p~Load,family=binomial(link=cloglog),weights=n)
summary(alloyf.glm.logit)
summary(alloyf.glm.probit)
summary(alloyf.glm.cloglog)
cbind(alloyf.glm.logit$fitted.values,alloyf.glm.probit$fitted.values,alloyf.glm.cloglog$fitted.values,p,alloyf.glm$linear.predictors)

#Swan and Rigby GLIM Newsletter
data <- read.table("NASA shuttle.dat",skip=1,header=T)
NASA=as.data.frame(data)
NASA  # 
nfail=NASA$nfail
temp=NASA$temp
#nfail 
six<-rep(6,times=23)
pfail=nfail/six
NASA.glm<-glm(pfail~temp,family=binomial(link=logit),weights=six)
summary(NASA.glm)
cbind(NASA.glm$fitted.values,pfail)

# samo nfail>0 
# mnogo e izkustveno. Plamen za po elegantno
sixx=rep(6,dim(NASA[NASA[,"nfail"]>0,])[1])
ppfail=NASA[NASA[,"nfail"]>0,]$nfail/sixx
NASA.glm<-glm(ppfail~temp,family=binomial(link=logit),weights=sixx,subset(NASA[NASA[,"nfail"]>0,]))
summary(NASA.glm)
