#BMDP example 149 - Cox data (1970), page 86
#
# Ungrouped binary data!!
#
#Unready<-c(0,0,1,0,1,0,1)	
#Tested<-c(55,155,2,152,7,13,3)
#Time<-c(7,14,14,27,27,51,51)
#cbind(Time,Tested,Unready)
data<- read.table("EX146-ungrouped.dat",skip=2,header=T)

EX146.logit<-glm(Unready ~ Time,family=binomial,weight=Tested,data)
summary(EX146.logit)
anova(EX146.logit,test="Chisq")
(residuals.glm (EX146.logit, type ="deviance"))#, "deviance", "pearson", "working", "response", "partial"),	     ...))

