############################## Grouped Binary Data
###                         
###
###           Beetle moratlity data - Bliss 1935 Quantal response models 
###
#Beetle mortality after five hours' exposure to gaseous carbon disulphide
#See also Stukel, T.A. (1988) "Generalized logistic models." JASA 83: 426-431.
#Dose Deaths Total
#We assume that $Deaths_i \~Binomial(Total_i,\pi_i)$ for $i=1,\ldots,8$ and that these 8 random variables are independent
options(contrasts=c("contr.treatment","contr.poly"))
data <- read.table("Beetle-Stukel.dat",skip=2,header=T)
Beetle.glm.logit <- glm( cbind(Deaths,Total-Deaths)~Dose,family=binomial,data=data)

summary(Beetle.glm.logit)
summary(Beetle.glm.logit, correlation=T)
summary(Beetle.glm.logit, correlation=F)
anova(Beetle.glm.logit,test="Chi")
#
#The Wald test is shown in the z value. To get the Likelihood Ratio Test, we need the log likelihood value 
#at the estimate and at the null value 0. For this we can use the deviance values.
#
LRT=Beetle.glm.logit$null.deviance-Beetle.glm.logit$deviance

#
# Type help(predict.glm) to see the options
#
predict.glm(Beetle.glm.logit, type="response", newdata=data.frame(Dose=1.8))
#
predict.glm(Beetle.glm.logit, type="response", newdata=data.frame(Dose=c(1.8840,1.8845,2,4)))
#
predict.glm(Beetle.glm.logit, type="response", newdata=data.frame(Dose=seq(1.8840,1.9,0.001)))


plot(Beetle.glm.logit)

plot(cooks.distance(Beetle.glm.logit,res=residuals(Beetle.glm.logit,type="pearson"),sd=1),
	main="Cook's distance - Binomial Residuals",
	xlab="Observation number",ylab="Cook's distance",pch=8)

qqnorm(residuals(Beetle.glm.logit,type="pearson")/sqrt(1-lm.influence(Beetle.glm.logit)$hat),
	main="Q-Q Plot - Binomial Residuals",xlab="Ordered normal",
	ylab="Ordered residual",pch=8)
abline(0,1)

plot(Dose,(Deaths/Total),
#	pch=8,xlab="Dose",ylab="Proportion with deaths",xlim=c(0,30))
	pch="*",xlab="Dose",ylab="Proportion with deaths",xlim=c(1.68,1.9))
lines(x=Dose,y=1/(1+exp(-coef(Beetle.glm.logit)[1]-coef(Beetle.glm.logit)[2]*Dose)),col="green")
#lines(x=Dose,y=1/(1+exp(-coef(Beetle.glm.probit)[1]-coef(Beetle.glm.probit)[2]*Dose)),col="blue")
# in power 2 of dose
Beetle.glm.logit2 <- glm( cbind(Deaths,Total-Deaths)~Dose+I(Dose^2),family=binomial )
summary(Beetle.glm.logit2)
anova(Beetle.glm.logit2,test="Chi")
#lines(x=Dose,y= 1/(1+exp(-coef(Beetle.glm.logit2)[1]-coef(Beetle.glm.logit2)[2]*Dose
#-coef(Beetle.glm.logit2)[3]*Dose^2)),col="violet")
a=seq(min(Dose),max(Dose),0.001)
lines(x=Dose,y= 1/(1+exp(-coef(Beetle.glm.logit2)[1]-coef(Beetle.glm.logit2)[2]*Dose
-coef(Beetle.glm.logit2)[3]*Dose^2)),col="violet")


Beetle.glm.probit <- glm( cbind(Deaths,Total-Deaths)~Dose,family=binomial(link=probit) )
summary(Beetle.glm.probit)
anova(Beetle.glm.probit,test="Chi")
lines(x=Dose,y=1/(1+exp(-coef(Beetle.glm.probit)[1]-coef(Beetle.glm.probit)[2]*Dose)),col="blue")

Beetle.glm.probit <- glm( cbind(Deaths,Total-Deaths)~Dose+I(Dose^2),family=binomial(link=probit) )
summary(Beetle.glm.probit)
anova(Beetle.glm.probit,test="Chi")
lines(x=Dose,y=1/(1+exp(-coef(Beetle.glm.probit)[1]-coef(Beetle.glm.probit)[2]*Dose
-coef(Beetle.glm.probit)[3]*Dose^2)),col="red")

Beetle.glm.cloglog <- glm( cbind(Deaths,Total-Deaths)~Dose+I(Dose^2),family=binomial(link=cloglog) )
summary(Beetle.glm.cloglog)
anova(Beetle.glm.cloglog,test="Chi")
lines(x=Dose,y=1/(1+exp(-coef(Beetle.glm.cloglog)[1]-coef(Beetle.glm.cloglog)[2]*Dose-coef(Beetle.glm.cloglog)[3]*Dose^2)),col="brown")

a=seq(min(Dose),max(Dose),0.001)
lines(x=a,y=1/(1+exp(-coef(Beetle.glm.probit)[1]-coef(Beetle.glm.probit)[2]*a)),col="brown")
lines(x=a,y=1/(1+exp(-coef(Beetle.glm.cloglog)[1]-coef(Beetle.glm.cloglog)[2]*a-coef(Beetle.glm.cloglog)[3]*a^2)),col="brown")


################## Beetle multiple linear regression model fit 
  Beetle.lm <- lm(Deaths/Total~Dose)
Beetle.lm.2 <- lm(Deaths/Total~Dose+I(Dose^2))
summary(Beetle.lm)
summary(Beetle.lm.2)
anova(Beetle.lm)
anova(Beetle.lm.2)
cbind(Deaths,Beetle.lm$fitted.values*Total,Beetle.lm.2$fitted.values*Total)


cbind(Deaths/Total,Beetle.glm.logit$fitted.values,Beetle.glm.probit$fitted.values,Beetle.glm.cloglog$fitted.values,Beetle.glm.logit2$fitted.values)
cbind(Deaths,Beetle.glm.logit$fitted.values*Total,Beetle.glm.probit$fitted.values*Total,Beetle.glm.cloglog$fitted.values*Total,Beetle.glm.logit2$fitted.values*Total)
cbind(Beetle.glm.logit$deviance,Beetle.glm.probit$deviance,Beetle.glm.cloglog$deviance,Beetle.glm.logit2$deviance)

(residuals.glm (Beetle.glm.cloglog, type ="deviance"))#, "deviance", "pearson", "working", "response", "partial"),	     ...))
cbind((residuals.glm (Beetle.glm.cloglog, type ="deviance")),(residuals.glm (Beetle.glm.cloglog, type ="pearson")),(residuals.glm (Beetle.glm.cloglog, type ="working")))#, "deviance", "pearson", "working", "response", "partial"),	     ...))
(residuals.glm (Beetle.glm.cloglog, type ="partial"))#, "deviance", "pearson", "working", "response", "partial"),	     ...))

#################### Beetle data  - analysis kogato dannite sa dadeni kato procenti 
p<-Deaths/Total
plot(Dose,p)
lines(Dose,p)
# ili 
#plot(Dose,p,type="l")
# Zabelejete weights!!!
Beetle.glm.p<-glm(p~Dose,weights=Total, family=binomial)
summary(Beetle.glm.p)
attributes(Beetle.glm.p)
anova(Beetle.glm.p,test="Chi")
lines(x=Dose,y=1/(1+exp(-coef(Beetle.glm.p)[1]-coef(Beetle.glm.p)[2]*Dose)),col="red")
plot(Beetle.glm.p,ask=T) #for diagnostic plots
cbind(Beetle.glm.p$fitted.values,p,Beetle.glm.p$linear.predictors)

