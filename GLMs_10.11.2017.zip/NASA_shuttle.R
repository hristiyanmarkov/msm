#
#Swan and Rigby GLIM Newsletter 1989
#
NASA <- read.table("NASA_shuttle.dat",skip=2,header=T)
head(NASA)
#
# replicated 0 and 1
#
NASA.glm<-glm(cbind(nfail,total-nfail)~temp,family=binomial(link=logit),data=NASA)
summary(NASA.glm)
anova(NASA.glm,test="Chisq")

par(mfrow=c(3,2))
plot(NASA.glm,which=1:6)

#
# frequences
#
six<-rep(6,times=dim(NASA)[1])
NASA.glm<-glm(nfail/total~temp,family=binomial(link=logit),weights=six,data=NASA)
summary(NASA.glm)
anova(NASA.glm,test="Chisq")

cbind(NASA.glm$fitted.values,NASA$nfail/NASA$total)
#
#  nfail>0 
# 
NASA.glm<-glm(nfail/total~temp,family=binomial(link=logit),
				weights=NASA[NASA[,"nfail"]>0,"total"],
				data=NASA[NASA[,"nfail"]>0,])
summary(NASA.glm)
anova(NASA.glm,test="Chisq")

