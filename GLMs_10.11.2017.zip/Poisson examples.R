#Dobson Table 4.3.

data <- read.table("Table.4.3.Poisson.Regression.txt",skip=2,header=T)
data=as.data.frame(data)

Table4.3.glm<-glm(y ~ x, data = data, family = poisson(link="identity"))

summary(Table4.3.glm)
anova(Table4.3.glm,test="Chi")
cbind(data$y,Table4.3.glm$fitted.values)
# see page 80 Table 5.1
cbind(data$y,Table4.3.glm$fitted.values,data$y*log(data$y/Table4.3.glm$fitted.values))


#Dobson Table 4.5. AIDS
data <- read.table("Table 4.5 AIDS cases.txt",skip=2,header=T)
data=as.data.frame(data)

Table4.5.glm<-glm(cases ~ log(year-mean(data$year)), data = data, family = poisson(link="log"))
summary(Table4.5.glm)
anova(Table4.5.glm,test="Chi")
cbind(data$cases,Table4.3.glm$fitted.values)


############################# Poisson Regression
#Numbers of Car Insurance claims
#Description
#The data given in data frame Insurance consist of 
#the numbers of policyholders of an insurance company 
#who were exposed to risk, and the numbers of car insurance 
#claims made by those policyholders in the third quarter of 1973. 
#
#Format This data frame contains the following columns: 
#
#District - district of policyholder (1 to 4): 4 is major cities. 
#Group    - group of car (1 to 4), <1 litre, 1�1.5 litre, 1.5�2 litre, >2 litre. 
#Age      - age of driver in 4 ordered groups, <25, 25�29, 30�35, >35. 
#Holders  - numbers of policyholders 
#Claims   - numbers of claims 
#Source
#L. A. Baxter, S. M. Coutts and G. A. F. Ross (1980) Applications of linear models in motor insurance. 
#Proceedings of the 21st International Congress of Actuaries, Zurich pp. 11�29 
#M. Aitkin, D. Anderson, B. Francis and J. Hinde (1989) Statistical Modelling in GLIM. 
#Oxford University Press
########## main-effects fit as Poisson GLM with offset


#library(MASS)
data <- read.table("InsClaims.dat",skip=16,header=T)
InsClaims=as.data.frame(data)
#options(contrasts=c("contr.treatment","contr.poly"))

District=InsClaims$District
   Group=InsClaims$Group
     Age=InsClaims$Age
 Holders=InsClaims$Holders 
  Claims=InsClaims$Claims

#District=as.factor(District)
#   Group=as.factor(Group)
#     Age=as.factor(Age)
#InsClaims=data.frame(InsClaims)     

Ins.glm<-glm(Claims ~ District + Group + Age + offset(log(Holders)),
               data = InsClaims, family = poisson)
MassIns.glm<-glm(Claims ~ District + Group + Age + offset(log(Holders)),
               data = Insurance, family = poisson)
#
#Ins.glm<-glm(Claims ~ District + Group + Age, offset=log(Holders),
#               data = InsClaims, family = poisson)

summary(Ins.glm)
anova(Ins.glm,test="Chi")
cbind(Claims,Ins.glm$fitted.values)


############################# Poisson Regression for Rates
#To model the rate of occurrence of an event over an exposure time, 
#dependent on covariates, a Poisson loglinear model is useful. 
#If the response count for the $i$th individual is $n_i$ over $t_i$ exposure time, then the
#expected rate is $\mu_i/ t_i$, the log of which is modeled is a linear function of covariates
#                  $\log (n_i/ t_i)=\beta_0+\beta_1 x$
#The term $\log (t_i)$ is then considered an offset.

#The data in Table9.1 - Heart valve operations will be used in thi example. 
#Patients were classified by type of heart valve (aortic, mitral) and age (< 55, 55+). 
#Follow-up observation lasted from the time of operation until the patient died or the study ended. 
#The follow-up observation for each patient is their time at risk, in months. 
#For each cell in the 2 x 2 table, the total time at risk is the sum of the times at risk
#for patients in that cell. Also recorded is the number of deaths per cell. 
#The sample death rate is then the number of deaths divided by the total time at risk.
#We fit fit a loglinear model to the responses because by glm as we want to
#include the offset term, exposure.

data <- read.table("table.9.11.dat",header=T)
table.9.11=as.data.frame(data)
   Valve=table.9.11$Valve
     Age=table.9.11$Age
  Deaths=table.9.11$Deaths
Exposure=table.9.11$Exposure

   Valve=as.factor(Valve)
     Age=as.factor(Age)
     
     Risk=Deaths/Exposure
table.9.11<-data.frame(table.9.11,Risk)

options(contrasts=c("contr.treatment", "contr.poly"))
fit.rate<-glm(Deaths~Valve+Age+offset(log(Exposure)),family=poisson,data=table.9.11)
summary(fit.rate)
anova(fit.rate,test="Chi")
# deviance = 6.663156021, df=1
#P(>|Chi|)
1-pchisq(6.663156021, df= 1) 
#
# The same result can be obtained as follows
# 
fit.rate.1<-glm(Deaths~Valve+Age,offset=log(Exposure),family=poisson,data=table.9.11)
summary(fit.rate.1)

#Thus, the estimated rate for the older age group (coded 1, 
#by the ordering of the levels) is exp(1.221) = 3.4 times 
#that for the younger group. 

exp(1.2209)

#The LR confidence interval
#
library(MASS)
exp(confint(fit.rate))

# chi-squared statistic, use resid()
#which is not a significantly poor fit at the .05 level.
chi.p=sum(resid(fit.rate,type="pearson")^2)
chi.d=sum(resid(fit.rate,type="deviance")^2)
1-pchisq(chi.p, df= 3)
1-pchisq(chi.d, df= 3)

#Fitted values are obtain by

mhat<-fitted(fit.rate)
exphat<-fitted(fit.rate)/Exposure
temp<-rbind(mhat,exphat)
array(temp,dim=c(2,2,2),dimnames=list(c("Deaths","Risk"),Valve=c("Aortic","Mitral"),Age=c("<55","55+")))
temp<-rbind(Deaths,Risk, mhat,exphat)
array(temp,dim=c(4,2,2),dimnames=list(c("Deaths","EmpRisk","Predicted Deaths","Risk"),Valve=c("Aortic","Mitral"),Age=c("<55","55+")))

#################################
data <- read.table("skin.dat",header=T)
skin=as.data.frame(data)

Counts=skin$Counts
  Type=skin$Type
  Site=skin$Site

skinfit=glm(Counts~Type+Site,family=poisson,skin)
summary(skinfit)
#
#Test the resulting residual deviance using the chi^2 distribution,
#
anova(skinfit,test="Chi")

#Check that this is the same 
#if you do the following using the resulting Residual deviance:  51.795  on  6
1-pchisq(51.795,6)

#This can be compared with the Pearson chi^2 statistic for a contingency table 
# \sum^n_{i=1}(P_i(O_i - E_i)^2/E_i 
#this is the classic test for �independence� in a table that you meet in elementary statistics:

aa=sum((skin$Counts-fitted(skinfit))^2/fitted(skinfit))
#1-pchisq(65.81158,6)
1-pchisq(aa,6)

#By either criterion, we conclude, overwhelmingly, that the additive model does NOT fit � that
#is (noting the sampling regime we believe to be relevant for these data, namely that 400 individuals
#are classified according to two response factors), that type and site are not independent in these
#data. Finally, we confirm that fitting interactions produces the saturated model, with no degrees of
#freedom left:
bb=glm(Counts~Type*Site,poisson,skin)
summary(bb)

########################### Poisson regression - cellular.dat
#data(cellular)
data <- read.table("cellular.dat",header=T)
cellular=as.data.frame(data)
cellular$TNF <- as.factor(cellular$TNF)
cellular$IFN <- as.factor(cellular$IFN)
model=as.formula("y ~ TNF + IFN")
mod <- glm(model, data=cellular, family=poisson(log))
summary(mod)
anova(mod,test="Chi")
plot(mod)
cbind(mod$fitted.values,cellular$y,mod$residuals,df.residual)

############################# Poisson regression Horsue data
#Crab data to fit a Poisson GLMs. Each female crab in the
#data set had a male crab resident in her nest. 
#The response variable measured was the number of
#additional males (satellites) residing nearby each female. 
#Explanatory variables were the female crab�s
#color, spine condition, weight and carapace width. 
#Width is the only explanatory variable used to fit the
#Poisson model in this section.
############################


# table.4.3$Sa.bin<-ifelse(table.4.3$Sa>0,1,0) if data have to analized as binary logistic regression
data <- read.table("table.4.3.dat",skip=8,header=T)
table.4.3=as.data.frame(data)

#
options(contrasts=c("contr.treatment", "contr.poly"))
#
 C=table.4.3$color     
 S=table.4.3$spine     
 W=table.4.3$width     
Sa=table.4.3$satellites
Wt=table.4.3$weight    

C.fac<-factor(C, levels=c("5","4","3","2"), labels=c("dark","med-dark","med","med-light"))
S.fac<-factor(S, levels=c("3","2","1"),labels=c("2good", "1broken", "2broken"))
is.factor(C.fac)
is.factor(S.fac)

crab.Poisson.W<-glm(Sa~W, family=poisson(log), data=table.4.3)
summary(crab.Poisson.W)
anova(crab.Poisson.W,test="Chi")
LRT=crab.Poisson.W$null.deviance-crab.Poisson.W$deviance

#The null deviance is the deviance value for a model with only an intercept. 
#The residual deviance is the deviance value for a model with both an intercept and width. 
#The reduction in deviance is a test of the width coefficient. That is
#crab.Poisson.W$null.deviance-crab.Poisson.W$deviance
#[1] 64.91309
#is the LR statistic for testing the significance of the Width variable in the model. 
#Compared to a chisquared distribution with 1 degree of freedom, 
#the p-value of this test is quite low, rejecting the null
#hypothesis of a zero-valued coefficient on width. 
#We can get similar information from the Wald test given
#by the z-value  to the coefficient estimate. 
#However, the LRT is usually considered more reliable
#
#To extract the estimated coefficients, along with their standard errors, type:

summary(crab.Poisson.W)$coefficients

#Thus, the fitted model is log(\mu)=-3.3047572+ 0.1640451W
#
# The fitted response values (expected values) at each of the width values in the model can
#be obtained by extracting the 

crab.Poisson.W$fitted.values.

#The same answer can be obtained by the call fitted(crab.Poisson.W). 
#The functions, fitted, resid, coef are shortened versions to extract 
#fitted values, residuals, and coefficients, respectively, from glm objects.
#Using the predict method for glm, we can get the fitted response value for any width value we input.
#For example, the expected number of satellites at a width of 26.3 is

predict.glm(crab.Poisson.W, type="response", newdata=data.frame(W=26.3))

#Poisson model with identity link to the Horseshoe Crab data.
#Because of convergence problems with the identity link, 
#we give the initial estimate as the estimated coefficients themselves. Thus, 

id.fit<-glm(Sa~W, family=poisson(link=identity),data=table.4.3, start=coef(crab.Poisson.W))
summary(id.fit)

#The fitted model is then 
#\mu= -11.52547+0.54925W
#mu= -11.52547+0.54925W
#Thus, carapace width has an additive impact on mean number of 
#satellites instead of multiplicative, as with the log link. 
#The additive effect is 0.55 (about half a satellite) per 1 cm increase in width. 
#A comparison of the two models predictions is is reproduced below.
#In R, there is a flexible package called plotmath in (in the library(base)  environment) 
#that can be used to create mathematical notation. 
#See below and help(plotmath)). 
#We also use the arrows command to make arrows. 

#W=seq(18,34,1)
#W.fac<-cut(W, breaks=c(0,seq(23.25, 29.25),Inf))
W.fac<-cut(W, breaks=c(0,seq(23.25, 29.25),Inf))
is.factor(W.fac)
levels(W.fac)

plot.y<-aggregate(Sa, by=list(W=W.fac), mean)$x
plot.x<-aggregate(W, by=list(W=W.fac), mean)$x
plot(x=plot.x, y=plot.y, ylab="Number of Satellites", xlab="Width (cm)",bty="L",
axes=F, type="p", pch=16)
axis(2, at=0:5)
axis(1, at=seq(20,34,2))

#Number of Satellites
plot(x=plot.x, y=plot.y, ylab=expression(paste("Mean number of satellites,",
{mu})), xlab="Width (cm)",bty="L",axes=F, type="p", pch=16)
 axis(2, at=0:5) 
 axis(1, at=seq(20,34,2))

ind<-order(W)
lines(x=W[ind],y=crab.Poisson.W$fitted.values[ind])
lines(x=W[ind],y=id.fit$fitted.values[ind])
#arrows(x1=23.5,y1=2.9,x2=23.5,y2=predict(crab.Poisson.W,newdata=data.frame(W=23.5),
#type="response"), open=T, size=.3)
#arrows(x0=23.5,y0=2.9,x1=23.5,y1=predict(crab.Poisson.W,newdata=data.frame(W=23.5),.2) 
#type="response"), length= text(x=23.5,y=3,"Log Link")
#arrows(x1=29.75,y1=3.1,x2=29.75,y2=predict(id.fit,newdata=data.frame(W=29.75),
#type="response"), open=T, size=.3)
#
arrows(x0=23.5,y0=2.9,x1=23.5,y1=predict(crab.Poisson.W,newdata=data.frame(W=23.5),
type="response"), length=.2)
text(x=23.5,y=2.9,"Log Link")
arrows(x0=29.75,y0=3.1,x1=29.75,y1=predict(id.fit,newdata=data.frame(W=29.75),
type="response"), length=.2)
text(x=29.75,y=2.9,"Identity Link")


#
# AIC for both models. A lower AIC implies a better model fit. 
# A comparison of residuals from each of the models may also be helpful.
#
summary.glm(log.fit)$aic 
summary.glm(id.fit)$aic



C.fac<-factor(C, levels=c("5","4","3","2"), labels=c("dark","med-dark","med","med-light"))
S.fac<-factor(S, levels=c("3","2","1"),labels=c("2good", "1broken", "2broken"))
is.factor(C.fac)
is.factor(S.fac)

crab.Poisson.WCS<-glm(Sa~C.fac+S.fac+W+I(Wt/1000), family=poisson(log), data=table.4.3)
summary(crab.Poisson.WCS)

#
# High vorrelation between W and Wt. One must be eliminated
#
anova(crab.Poisson.W,crab.Poisson.WCS,test="Chi")
#

crab.Poisson.intWCS<-glm(Sa~C.fac*S.fac*W, family=poisson(log), data=table.4.3)
summary(crab.Poisson.intWCS)

res <- step(crab.Poisson.intWCS, list(lower = ~ 1, upper =
formula(crab.Poisson.intWCS)), scale = 1, trace = F, direction = "backward")

res$anova

###################################### Residuals in GLms
#Residuals for GLIMs
#To demonstrate how to obtain the residuals we use the Horseshoe Crab data fit.
#For example, the Pearson and deviance residuals are obtained from

resid(crab.Poisson.W, type="deviance")
pear.res<-resid(crab.Poisson.W, type="pearson")

#The standardized Pearson residuals are obtained by dividing the output from resid by a function of the
#hat diagonal values, obtained from the lm.influence function.

pear.std<-resid(crab.Poisson.W, type="pearson")/sqrt(1-lm.influence(crab.Poisson.W)$hat) 

#However, as most of the hat diagonals are very small, there is really no difference between the two sets
#of residuals, as the following graph shows.
par(mfrow=c(2,2))
plot(pear.res, xlab="observation",ylab="Pearson Residuals")
abline(h=0)
plot(pear.std, xlab="observation",ylab="Standardized Pearson Residuals")
abline(h=0)

#Issuing the command plot(crab.Poisson.W) may also be useful:

par(mfrow=c(1,2))
old.par<-par(pty="s") # save old pty settings
par(pty="s") # change pty par setting to �s�
plot(crab.Poisson.W)
par(old.par) # change back to old pty settings

##########################################
# Negative Binomial GLMs
#
#For count data, a negative binomial random component has a second parameter in additional to the
#mean, called the dispersion parameter. The smaller the dispersion parameter, the larger the
#variance as compared to the mean. But, with growing dispersion parameter, the variance converges to
#the mean, and the random quantity converges to the Poisson distribution. Actually, negative binomial is
#the distribution of a Poisson count with gamma-distributed rate parameter.
#There are several methods for going about fitting a negative binomial GLMs in R. If the
#dispersion parameter is known, then the MASS library has a negative.binomial family function to use
#with glm. For example, to fit a negative binomial GLMs to the Horseshoe Crab data, where the dispersion
#parameter (called theta in the function) is fixed to be 1.0, we can use library(MASS)

library(MASS)                                                                
crab.neg.bin.W <-glm(Sa~W, family=negative.binomial(theta=1.0,link="identity"),data=table.4.3,
start=coef(crab.Poisson.W, type="link"))       
summary(crab.neg.bin.W)

#A simpler version of negative.binomial (called neg.bin, with only the log link) is also available from
#MASS, as well as a function called glm.nb. The function glm.nb allows one to estimate theta using MLE. 
#The output is similar to that of glm and has a summary method.
library(MASS)
crab.nb.fit.W<-glm.nb(Sa ~ W, data = table.4.3, init.theta=1.0, link=identity,
start=coef(id.fit, type="link"))
summary(crab.nb.fit.W)


##############################
# GLMs single Poisson regression model 
#
#
data=read.table("seizure.dat",header=T)
seizure=as.data.frame(data)                   
 
 Seizures=seizure$Seizures 
    Hours=seizure$Hours 
Treatment=seizure$Treatment 
      Day=seizure$Day   
Treatment=as.factor(Treatment)      
is.factor(Treatment)

plot(Seizures/Hours~Day, col=as.integer(Treatment),
     pch=as.integer(Treatment), data=seizure)
abline(v=27.5, lty=2, col="grey")
legend(140, 9, c("Baseline", "Treatment"),
       pch=1:2, col=1:2, xjust=1, yjust=1)
       
seizGLM <- glm(Seizures~Treatment*log(Day),family=poisson,offset=log(Hours))
summary( seizGLM)
fitted(seizGLM)
matplot(Day, fitted(seizGLM)/Hours, type="l", add=TRUE, col=6:7)

################ Mixtires of two Poisson distributions
library(flexmix)
seizMix <- flexmix(Seizures~Treatment*log(Day),k=2,
#                   data=seizure, k=2,
                   model=FLXMRglm(family="poisson", offset=log(Hours)))

summary(seizMix)
summary(refit(seizMix))

matplot(Day, fitted(seizMix)/Hours, type="l",
        add=TRUE, col=3:4)

###############################################

### Name: glm.control
### Title: Auxiliary for Controlling GLM Fitting
### Aliases: glm.control
### Keywords: optimize models

### ** Examples

### A variation on  example(glm) :

## Annette Dobson's example ...
counts <- c(18,17,15,20,10,20,25,13,12)
outcome <- gl(3,1,9)
treatment <- gl(3,3)
oo <- options(digits = 12) # to see more when tracing :
glm.D93X <- glm(counts ~ outcome + treatment, family=poisson(),
                trace = TRUE, epsilon = 1e-14)
options(oo)
coef(glm.D93X) # the last two are closer to 0 than in ?glm's  glm.D93

summary(glm.D93X)
anova(glm.D93X,test="Chi")                

#######################################################
data <- read.table("ch3e5.dat",skip=6,header=T)
#attach(data)
data=as.data.frame(data)
Tetrahydrocortisone=data$Tetrahydrocortisone
Pregnanetriol      =data$Pregnanetriol      
Type               =data$Type               

Tetrahydrocortisone <- rep(Tetrahydrocortisone,3)
Pregnanetriol <- rep(Pregnanetriol,3)
Response <- c(Type==1,Type==2,Type==3)
Type <- factor(c(rep(1,21),rep(2,21),rep(3,21)),
	labels=c("Adenoma","BilateralHyperplasia","Carcinoma"))
Expl <- gl(21,1,63)

z1 <- glm(Response~Type+Expl,family=poisson)
z2 <- glm(Response~Type+Expl+Type:Tetrahydrocortisone,family=poisson)
z3 <- glm(Response~Type+Expl+Type:Pregnanetriol,family=poisson)
summary(z4 <- glm(Response~Type+Expl+Type:(Tetrahydrocortisone+
Pregnanetriol),family=poisson))
z5 <- glm(Response~Type+Expl+Type:(Tetrahydrocortisone*Pregnanetriol),
	family=poisson)


plot(cooks.distance(z4,res=residuals(z4,type="pearson"),sd=1),
	main="Cook's distance - Poisson Residuals",
	xlab="Observation number",ylab="Cook's distance",pch=8)

qqnorm(residuals(z4,type="pearson")/sqrt(1-lm.influence(z4)$hat),
	main="Q-Q Plot - Poisson Residuals",xlab="Ordered normal",
	ylab="Ordered residual",pch=8)
abline(0,1)


print(z6 <- glm(Response~Type+Expl+Type:(log(Tetrahydrocortisone)+
	log(Pregnanetriol)),family=poisson))
plot(cooks.distance(z6,res=residuals(z6,type="pearson"),sd=1),
	main="Cook's distance - Poisson Residuals",
	xlab="Observation number",ylab="Cook's distance",pch=8)

qqnorm(residuals(z6,type="pearson")/sqrt(1-lm.influence(z6)$hat),
	main="Q-Q Plot - Poisson Residuals",xlab="Ordered normal",
	ylab="Ordered residual",pch=8)
abline(0,1)
